#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
for cmd in python3 git rustup xcodebuild xcodegen pod; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "Missing tool: $cmd (see README.md)" >&2
    exit 1
  fi
done
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip numpy
python scripts/prepare_assets.py
bash scripts/build_seag2p_ios.sh
xcodegen generate
pod install
printf '\nOpen HNVieNeuIOS.xcworkspace in Xcode, set Signing team, choose iPhone, Run.\n'
