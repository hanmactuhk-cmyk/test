#!/usr/bin/env python3
"""Make ONNX boolean masks compatible with the Objective-C ONNX Runtime 1.30 APIs.

The public iOS API exposes uint8 tensors but has no BOOL enum; external mask
inputs become UINT8 followed by a Cast back to BOOL for all existing nodes.
"""
from pathlib import Path
import onnx
from onnx import TensorProto, helper

root = Path(__file__).resolve().parents[1]
for model_name, mask_name in [('duration_predictor','ctx_mask'),
                               ('vector_estimator','ctx_mask'),
                               ('reference_encoder','ref_mask')]:
    path = root / 'Models' / f'{model_name}.onnx'
    model = onnx.load(str(path))
    graph = model.graph
    targets = [x for x in graph.input if x.name == mask_name]
    if len(targets) != 1:
        raise RuntimeError(f'{model_name}: missing {mask_name}, found {[x.name for x in graph.input]}')
    mask = targets[0]
    if mask.type.tensor_type.elem_type == TensorProto.UINT8:
        print('Already patched',model_name)
        continue
    if mask.type.tensor_type.elem_type != TensorProto.BOOL:
        raise RuntimeError(f'{model_name}: unexpected element type {mask.type.tensor_type.elem_type}')
    internal = f'{mask_name}__boolean'
    num_rewrites = 0
    for node in graph.node:
        for i, name in enumerate(node.input):
            if name == mask_name:
                node.input[i] = internal
                num_rewrites += 1
    assert num_rewrites > 0
    mask.type.tensor_type.elem_type = TensorProto.UINT8
    graph.node.insert(0, helper.make_node('Cast',inputs=[mask_name],outputs=[internal],
                                          to=TensorProto.BOOL,name=f'Bridge_{mask_name}_u8_to_bool'))
    onnx.save(model, str(path))
    onnx.checker.check_model(str(path))
    print('Patched',model_name, mask_name, 'for iOS runtime')
