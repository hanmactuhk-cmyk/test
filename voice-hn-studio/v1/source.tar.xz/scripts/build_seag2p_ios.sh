#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$ROOT/.cache" "$ROOT/Native/include"
if ! command -v rustup >/dev/null; then
  echo 'Missing Rust. Install rustup from https://rustup.rs/' >&2; exit 1
fi
if ! command -v xcodebuild >/dev/null; then
  echo 'Missing Xcode command line tools on macOS.' >&2; exit 1
fi
CHECKOUT="$ROOT/.cache/sea-g2p"
if [ ! -d "$CHECKOUT/.git" ]; then
  git clone --depth=1 --branch v0.10.0 https://github.com/pnnbao97/sea-g2p.git "$CHECKOUT"
fi
# The project defaults to cdylib; iOS requires a statically-linked library.
python3 - "$CHECKOUT/Cargo.toml" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1]); txt = p.read_text()
txt = txt.replace('crate-type = ["cdylib", "rlib"]', 'crate-type = ["staticlib", "rlib"]')
if 'crate-type = ["staticlib", "rlib"]' not in txt:
    raise SystemExit('Unknown SEA-G2P Cargo.toml: update build script')
p.write_text(txt)
PY
cp "$CHECKOUT/include/sea_g2p.h" "$ROOT/Native/include/sea_g2p.h"
cd "$CHECKOUT"
rustup target add aarch64-apple-ios aarch64-apple-ios-sim
cargo build --release --target aarch64-apple-ios --no-default-features --features capi
cargo build --release --target aarch64-apple-ios-sim --no-default-features --features capi
rm -rf "$ROOT/Native/SeaG2P.xcframework"
xcodebuild -create-xcframework \
 -library "$CHECKOUT/target/aarch64-apple-ios/release/libsea_g2p_rs.a" -headers "$ROOT/Native/include" \
 -library "$CHECKOUT/target/aarch64-apple-ios-sim/release/libsea_g2p_rs.a" -headers "$ROOT/Native/include" \
 -output "$ROOT/Native/SeaG2P.xcframework"
printf 'SEA-G2P built for physical iPhone + Apple Silicon simulator.\n'
