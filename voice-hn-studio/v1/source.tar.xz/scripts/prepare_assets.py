#!/usr/bin/env python3
"""Download VieNeu-TTS Nano weights only for APP BUILD, never at runtime.

Run on a Mac/PC with Internet before generating the Xcode project. Once
installed on iPhone, the app contains all weights, voices and sea_g2p.bin and
uses no network.
"""
import json
import os
import sys
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODELS = ROOT / 'Models'
DATA = ROOT / 'Data'
HF = 'https://huggingface.co/pnnbao-ump/VieNeu-TTS-v3-Nano/resolve/main/'
GH = 'https://raw.githubusercontent.com/pnnbao97/VieNeu-TTS/main/src/vieneu/assets/voices_v3_nano.json'
FILES = {
    'text_encoder.onnx': 20_000_000,
    'duration_predictor.onnx': 500_000,
    'vector_estimator.onnx': 100_000_000,
    'codec_decoder.onnx': 50_000_000,
    'speaker_encoder.onnx': 1_000_000,
    'codec_encoder.onnx': 1_000_000,
    'reference_encoder.onnx': 1_000_000,
    'config.json': 1000,
    'constants.npz': 1000,
}


def download(url, out, min_size):
    if out.exists() and out.stat().st_size > min_size:
        print('✓ already present:', out.name)
        return
    print('↓ downloading:', out.name, flush=True)
    tmp = out.with_suffix(out.suffix + '.part')
    req = urllib.request.Request(url, headers={'User-Agent': 'HN-VieNeu-offline-build/0.1'})
    try:
        with urllib.request.urlopen(req, timeout=120) as resp, tmp.open('wb') as f:
            total = 0
            while True:
                chunk = resp.read(1024 * 1024)
                if not chunk:
                    break
                f.write(chunk)
                total += len(chunk)
                if total % (32 * 1024 * 1024) < 1024 * 1024:
                    print(f'    {total / (1024 * 1024):.0f} MB', flush=True)
        if tmp.stat().st_size <= min_size:
            raise RuntimeError(f'{out.name} too small: {tmp.stat().st_size}')
        tmp.replace(out)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise


def extract_dictionary():
    dest = DATA / 'sea_g2p.bin'
    if dest.exists() and dest.stat().st_size > 1024:
        print('✓ SEA-G2P dictionary already present')
        return
    # The upstream Python wheel ships the exact binary dictionary used by the Rust core.
    import subprocess
    wheels = ROOT / '.cache' / 'wheels'
    wheels.mkdir(parents=True, exist_ok=True)
    subprocess.check_call([sys.executable, '-m', 'pip', 'download', '--only-binary=:all:',
                           '--no-deps', '-d', str(wheels), 'sea-g2p==0.10.0'])
    files = sorted(wheels.glob('sea_g2p*.whl'))
    if not files:
        raise RuntimeError('SEA-G2P wheel missing. Provide Data/sea_g2p.bin manually.')
    with zipfile.ZipFile(files[-1]) as z:
        matches = [name for name in z.namelist() if name.endswith('sea_g2p.bin')]
        if len(matches) != 1:
            raise RuntimeError(f'SEA-G2P dictionary not found in wheel: {matches}')
        dest.write_bytes(z.read(matches[0]))
    print('✓ Dictionary', dest.stat().st_size, 'bytes')


def main():
    try:
        import numpy as np
    except ImportError:
        raise SystemExit('Install Python dependency first: python3 -m pip install numpy')
    MODELS.mkdir(exist_ok=True)
    DATA.mkdir(exist_ok=True)
    for name, size in FILES.items():
        dest = MODELS / name if name.endswith('.onnx') else DATA / name
        download(HF + name + '?download=true', dest, size)
    download(GH, DATA / 'voices_v3_nano.json', 5000)
    with np.load(DATA / 'constants.npz', allow_pickle=False) as arrays:
        null_spk = np.asarray(arrays['null_spk'], dtype=np.float32).ravel().tolist()
        null_style = np.asarray(arrays['null_style'], dtype=np.float32).ravel().tolist()
        latent_mean = np.asarray(arrays['latent_mean'], dtype=np.float32).ravel().tolist()
        latent_std = np.asarray(arrays['latent_std'], dtype=np.float32).ravel().tolist()
        latent_scale = float(arrays['latent_scale']) if 'latent_scale' in arrays else 1.0
    assert len(null_spk) == 192, len(null_spk)
    assert len(null_style) == 50 * 256, len(null_style)
    assert len(latent_mean) == len(latent_std) == 24
    (DATA / 'constants.json').write_text(json.dumps({'null_spk': null_spk,
                                                     'null_style': null_style,
                                                     'latent_mean': latent_mean,
                                                     'latent_std': latent_std,
                                                     'latent_scale': latent_scale}, separators=(',', ':')))
    config = json.loads((DATA / 'config.json').read_text())
    assert 'vocab' in config and 'bos_id' in config
    voices = json.loads((DATA / 'voices_v3_nano.json').read_text())
    assert voices['presets'], 'Voice preset file empty'
    extract_dictionary()
    print(f'✓ All offline assets ready ({len(voices["presets"])} preset voices)')
    print('No download/network code is included in the iPhone app.')

if __name__ == '__main__':
    main()
