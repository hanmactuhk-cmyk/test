import Foundation

/// Minimal typed tensor wrapper over onnxruntime-objc.
struct OrtTensor {
    enum Elements {
        case floats([Float]), int64([Int64]), bools([UInt8])
    }
    let shape: [Int]
    let elements: Elements

    static func f(_ a: [Float], _ s: [Int]) -> OrtTensor { .init(shape: s, elements: .floats(a)) }
    static func i(_ a: [Int64], _ s: [Int]) -> OrtTensor { .init(shape: s, elements: .int64(a)) }
    static func b(_ a: [UInt8], _ s: [Int]) -> OrtTensor { .init(shape: s, elements: .bools(a)) }

    var floats: [Float] {
        if case .floats(let a) = elements { return a }
        return []
    }
    func value() throws -> ORTValue {
        let data: Data
        let dtype: ORTTensorElementDataType
        switch elements {
        case .floats(let x):
            guard shape.reduce(1, *) == x.count else { throw TTSError.invalidModel("Kích thước Float tensor") }
            data = x.withUnsafeBufferPointer { Data(buffer: $0) }; dtype = .float
        case .int64(let x):
            guard shape.reduce(1, *) == x.count else { throw TTSError.invalidModel("Kích thước Int64 tensor") }
            data = x.withUnsafeBufferPointer { Data(buffer: $0) }; dtype = .int64
        case .bools(let x):
            guard shape.reduce(1, *) == x.count else { throw TTSError.invalidModel("Kích thước Bool tensor") }
            data = Data(x); dtype = .uInt8
        }
        return try ORTValue(tensorData: NSMutableData(data: data), elementType: dtype, shape: shape.map { NSNumber(value: $0) })
    }
}

final class OrtGraphs {
    private let env: ORTEnv
    private let sessions: [String: ORTSession]
    private let outputs: [String: String]

    init(models requiredModels: [String] = Assets.modelNames) throws {
        env = try ORTEnv(loggingLevel: .warning)
        let opt = try ORTSessionOptions()
        try opt.setIntraOpNumThreads(2)
        var models: [String: ORTSession] = [:]
        var outputKeys: [String: String] = [:]
        for file in requiredModels {
            let key = String(file.dropLast(5))
            let sess = try ORTSession(env: env, modelPath: Assets.modelPath(file), sessionOptions: opt)
            guard let first = try sess.outputNames().first else { throw TTSError.invalidModel("\(file) không có output") }
            models[key] = sess; outputKeys[key] = first
        }
        sessions = models; outputs = outputKeys
    }

    func firstInputName(_ model: String) throws -> String {
        guard let session = sessions[model], let first = try session.inputNames().first else {
            throw TTSError.invalidModel("Không nhận được đầu vào giọng đọc.")
        }
        return first
    }

    func run(_ model: String, _ x: [String: OrtTensor]) throws -> OrtTensor {
        guard let session = sessions[model], let output = outputs[model] else {
            throw TTSError.invalidModel("Không có model \(model)")
        }
        var prepared: [String: ORTValue] = [:]
        for (key, tensor) in x { prepared[key] = try tensor.value() }
        let results = try session.run(withInputs: prepared, outputNames: Set([output]), runOptions: nil)
        guard let val = results[output] else { throw TTSError.invalidModel("Không có output của \(model)") }
        let shape = try val.tensorTypeAndShapeInfo().shape.map { $0.intValue }
        let data = try val.tensorData() as Data
        guard data.count % MemoryLayout<Float>.size == 0 else { throw TTSError.invalidModel("Output không phải Float32 \(model)") }
        let floats: [Float] = data.withUnsafeBytes { Array($0.bindMemory(to: Float.self)) }
        guard shape.reduce(1, *) == floats.count else { throw TTSError.invalidModel("Output sai shape \(model)") }
        return .f(floats, shape)
    }
}
