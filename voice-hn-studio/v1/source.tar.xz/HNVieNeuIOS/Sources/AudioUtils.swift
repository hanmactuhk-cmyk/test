import Foundation

enum AudioUtils {
    static let sampleRate = 24_000

    static func trimAndFade(_ audio: [Float]) -> [Float] {
        guard !audio.isEmpty else { return [] }
        // The upstream engine has a specialized silence trim; this conservative
        // mobile trim only removes leading/trailing < -52 dB tails.
        let threshold: Float = 0.0025
        var start = 0
        while start < audio.count && abs(audio[start]) <= threshold { start += 1 }
        guard start < audio.count else { return [] }
        var end = audio.count - 1
        while end > start && abs(audio[end]) <= threshold { end -= 1 }
        let margin = 720 // 30 ms; preserve consonants near the speech boundary
        let first = max(0, start - margin)
        let last = min(audio.count, end + margin + 1)
        var out = Array(audio[first..<last]).map { max(-1, min(1, $0.isFinite ? $0 : 0)) }
        let fade = min(out.count / 2, 240)
        if fade > 0 {
            for i in 0..<fade {
                let gain = Float(i) / Float(fade)
                out[i] *= gain
                out[out.count - 1 - i] *= gain
            }
        }
        return out
    }
}

enum WAVWriter {
    static func save(_ samples: [Float]) throws -> URL {
        guard !samples.isEmpty else { throw TTSError.noGeneratedAudio }
        let directory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask,
                                                    appropriateFor: nil, create: true)
        let timestamp = ISO8601DateFormatter().string(from: Date()).replacingOccurrences(of: ":", with: "-")
        let url = directory.appendingPathComponent("Voice-Hn-Studio-\(timestamp).wav")
        var data = Data(capacity: 44 + samples.count * 2)
        func ascii(_ string: String) { data.append(contentsOf: string.utf8) }
        func i16(_ number: UInt16) { var le = number.littleEndian; withUnsafeBytes(of: &le) { data.append(contentsOf: $0) } }
        func i32(_ number: UInt32) { var le = number.littleEndian; withUnsafeBytes(of: &le) { data.append(contentsOf: $0) } }
        guard samples.count < Int(UInt32.max / 2) else { throw TTSError.invalidModel("File WAV quá lớn") }
        let byteCount = UInt32(samples.count * 2)
        ascii("RIFF"); i32(36 + byteCount); ascii("WAVE")
        ascii("fmt "); i32(16); i16(1); i16(1)
        i32(UInt32(AudioUtils.sampleRate)); i32(UInt32(AudioUtils.sampleRate * 2))
        i16(2); i16(16)
        ascii("data"); i32(byteCount)
        for s in samples {
            let limited = max(-1, min(1, s.isFinite ? s : 0))
            let n = Int16((limited * 32767).rounded())
            i16(UInt16(bitPattern: n))
        }
        try data.write(to: url, options: .atomic)
        return url
    }
}
