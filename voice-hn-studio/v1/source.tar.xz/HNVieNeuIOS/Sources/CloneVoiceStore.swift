import Foundation

/// User-owned voice profiles stay inside the app documents directory.
struct SavedVoice: Codable, Identifiable, Sendable {
    let id: String
    var name: String
    var description: String
    var createdAt: Date
    var speaker_emb: [Float]
    var style: [[Float]]

    var nanoVoice: NanoVoice {
        NanoVoice(description: description, gender: nil, speaker_emb: speaker_emb, style: style)
    }
}

enum CloneVoiceStore {
    private static var directory: URL {
        let root = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return root.appendingPathComponent("MyVoices", isDirectory: true)
    }

    static func all() -> [SavedVoice] {
        guard let urls = try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil) else { return [] }
        return urls.filter { $0.pathExtension.lowercased() == "json" }.compactMap { try? JSONDecoder().decode(SavedVoice.self, from: Data(contentsOf: $0)) }
            .sorted { $0.createdAt > $1.createdAt }
    }

    static func load(id: String) -> SavedVoice? {
        guard id.hasPrefix("mine-"), !id.contains("/"), !id.contains("..") else { return nil }
        let url = directory.appendingPathComponent(id).appendingPathExtension("json")
        guard let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(SavedVoice.self, from: data)
    }

    static func save(name: String, description: String, speaker: [Float], style: [[Float]]) throws -> SavedVoice {
        let normalized = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty else { throw TTSError.invalidVoice("Vui lòng đặt tên cho giọng mới.") }
        guard speaker.count == 192, style.count == 50, style.allSatisfy({ $0.count == 256 }) else {
            throw TTSError.invalidVoice("Không thể tạo dữ liệu giọng từ bản ghi này.")
        }
        guard speaker.allSatisfy(\.isFinite), style.flatMap({ $0 }).allSatisfy(\.isFinite) else {
            throw TTSError.invalidVoice("Dữ liệu giọng không hợp lệ.")
        }
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let profile = SavedVoice(id: "mine-" + UUID().uuidString.lowercased(), name: normalized, description: description,
                                 createdAt: Date(), speaker_emb: speaker, style: style)
        let bytes = try JSONEncoder().encode(profile)
        try bytes.write(to: directory.appendingPathComponent(profile.id).appendingPathExtension("json"), options: .atomic)
        return profile
    }

    static func delete(_ id: String) throws {
        guard id.hasPrefix("mine-"), !id.contains("/") else { return }
        try FileManager.default.removeItem(at: directory.appendingPathComponent(id).appendingPathExtension("json"))
    }
}
