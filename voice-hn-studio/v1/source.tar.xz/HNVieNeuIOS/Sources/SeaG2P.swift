import Foundation

/// Calls the actual SEA-G2P Rust C ABI compiled into SeaG2P.xcframework.
/// All phonemization happens locally. No HTTP, no Apple system voices.
final class SeaG2P {
    private let handle: OpaquePointer

    init() throws {
        guard sea_g2p_abi_version() == 1 else { throw TTSError.invalidModel("SEA-G2P ABI không tương thích") }
        let path = try Assets.dataURL("sea_g2p.bin").path
        guard let p = path.withCString({ sea_g2p_open($0) }) else {
            let err = sea_g2p_last_error().map { String(cString: $0) } ?? "Unknown"
            throw TTSError.invalidModel("SEA-G2P không mở được từ điển: \(err)")
        }
        handle = p
    }

    deinit { sea_g2p_close(handle) }

    func phones(_ text: String) throws -> String {
        guard let ptr = text.withCString({ sea_g2p_phonemize(handle, $0, 1) }) else {
            let err = sea_g2p_last_error().map { String(cString: $0) } ?? "Unknown"
            throw TTSError.inferenceFailure("SEA-G2P: \(err)")
        }
        defer { sea_g2p_string_free(ptr) }
        return String(cString: ptr)
    }
}
