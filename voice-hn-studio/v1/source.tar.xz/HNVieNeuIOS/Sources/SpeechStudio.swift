import AVFoundation
import Foundation
import SwiftUI

struct VoiceChoice: Identifiable {
    let id: String
    let title: String
    let detail: String
    let symbol: String
    let tint: Color
    let isPersonal: Bool
}

@MainActor
final class SpeechStudio: ObservableObject {
    @Published var text = ""
    @Published var voiceChoices: [VoiceChoice] = []
    @Published var selectedVoice = ""
    @Published var speed: Double = 1
    @Published var steps: Int = 8
    @Published var progress = ""
    @Published var errorText: String?
    @Published var busy = false
    @Published var resultURL: URL?
    @Published var playing = false
    @Published var history: [URL] = []

    private var player: AVAudioPlayer?

    init() { refresh() }

    func refresh() {
        var choices: [VoiceChoice] = []
        if let path = try? Assets.dataURL("voices_v3_nano.json"),
           let data = try? Data(contentsOf: path),
           let preset = try? JSONDecoder().decode(NanoVoices.self, from: data) {
            let keys = preset.presets.keys.sorted()
            let tints: [Color] = [.pink, .cyan, .purple, .orange, .mint, .blue]
            choices = keys.enumerated().map { index, key in
                let voice = preset.presets[key]
                return VoiceChoice(id: key, title: key, detail: voice?.description ?? "Giọng đọc tiếng Việt",
                                   symbol: "waveform", tint: tints[index % tints.count], isPersonal: false)
            }
            if selectedVoice.isEmpty { selectedVoice = preset.default_voice }
        }
        let personal = CloneVoiceStore.all().map {
            VoiceChoice(id: $0.id, title: $0.name, detail: $0.description.isEmpty ? "Giọng bạn đã tạo" : $0.description,
                        symbol: "person.wave.2.fill", tint: .cyan, isPersonal: true)
        }
        voiceChoices = personal + choices
        if !voiceChoices.contains(where: { $0.id == selectedVoice }) { selectedVoice = voiceChoices.first?.id ?? "" }
        let folder = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        history = ((try? FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.contentModificationDateKey])) ?? [])
            .filter { $0.pathExtension.lowercased() == "wav" }
            .sorted { a, b in
                let left = (try? a.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? .distantPast
                let right = (try? b.resourceValues(forKeys: [.contentModificationDateKey]))?.contentModificationDate ?? .distantPast
                return left > right
            }
    }

    var selectedLabel: String { voiceChoices.first(where: { $0.id == selectedVoice })?.title ?? "Chọn giọng đọc" }

    func synthesize() {
        guard !busy else { return }
        errorText = nil
        guard Assets.ready else { errorText = "Ứng dụng chưa sẵn sàng. Hãy kiểm tra bộ cài."; return }
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            errorText = "Vui lòng nhập nội dung cần đọc."; return
        }
        busy = true; resultURL = nil; progress = "Đang chuẩn bị giọng…"
        player?.stop(); playing = false
        let copy = text
        let chosen = selectedVoice
        let args = TTSSettings(voice: chosen, steps: steps, cfg: 3, sway: steps == 8 ? -1 : 0,
                               speed: Float(speed), seed: UInt64.random(in: 0...UInt64.max))
        Task.detached(priority: .userInitiated) { [self] in
            do {
                let engine = try NanoEngine()
                let samples = try engine.synthesize(copy, settings: args) { done, total in
                    Task { @MainActor in self.progress = "Đã tạo \(done)/\(total) đoạn" }
                }
                let url = try WAVWriter.save(samples)
                await MainActor.run { self.finish(url: url, sampleCount: samples.count) }
            } catch { await MainActor.run { self.fail(error.localizedDescription) } }
        }
    }

    private func finish(url: URL, sampleCount: Int) {
        resultURL = url
        progress = "Hoàn tất · \(Int(Double(sampleCount) / 24_000)) giây"
        busy = false
        refresh()
    }
    private func fail(_ message: String) {
        errorText = message; progress = "Không tạo được âm thanh"; busy = false
    }

    func playOrPause(_ chosenURL: URL? = nil) {
        guard let url = chosenURL ?? resultURL else { return }
        do {
            if player == nil || player?.url != url {
                try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
                try AVAudioSession.sharedInstance().setActive(true)
                player = try AVAudioPlayer(contentsOf: url)
                player?.prepareToPlay()
            }
            if player?.isPlaying == true { player?.pause(); playing = false }
            else { player?.play(); playing = true }
        } catch { errorText = "Không phát được âm thanh: \(error.localizedDescription)" }
    }

    func importText(from url: URL) {
        let scope = url.startAccessingSecurityScopedResource()
        defer { if scope { url.stopAccessingSecurityScopedResource() } }
        do {
            let data = try Data(contentsOf: url)
            guard let s = String(data: data, encoding: .utf8) else { errorText = "Vui lòng chọn tệp UTF-8"; return }
            text = url.pathExtension.lowercased() == "srt" ? SubtitleParser.toPlainText(s) : s
            errorText = nil
        } catch { errorText = "Không đọc được file: \(error.localizedDescription)" }
    }
}

@MainActor
final class CloneStudio: ObservableObject {
    @Published var name: String = ""
    @Published var descriptionText: String = "Ấm áp · Rõ lời"
    @Published var fileURL: URL?
    @Published var fileName: String = ""
    @Published var isRecording = false
    @Published var busy = false
    @Published var status = ""
    @Published var errorText: String?
    @Published var saved: [SavedVoice] = []

    private var recorder: AVAudioRecorder?

    init() { reload() }
    func reload() { saved = CloneVoiceStore.all() }
    func importAudio(_ url: URL) { fileURL = url; fileName = url.lastPathComponent; errorText = nil }

    func toggleRecording() {
        if isRecording {
            recorder?.stop(); recorder = nil; isRecording = false
            status = "Đã ghi âm. Bạn có thể tạo giọng mới."
            return
        }
        AVAudioSession.sharedInstance().requestRecordPermission { [weak self] allowed in
            DispatchQueue.main.async {
                guard let self else { return }
                guard allowed else { self.errorText = "Bạn cần cho phép sử dụng micro để ghi âm."; return }
                self.startRecording()
            }
        }
    }
    private func startRecording() {
        do {
            let folder = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                .appendingPathComponent("SampleRecordings", isDirectory: true)
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let url = folder.appendingPathComponent("reference-\(UUID().uuidString).wav")
            try AVAudioSession.sharedInstance().setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker])
            try AVAudioSession.sharedInstance().setActive(true)
            let options: [String: Any] = [AVFormatIDKey: Int(kAudioFormatLinearPCM), AVSampleRateKey: 24_000,
                                           AVNumberOfChannelsKey: 1, AVLinearPCMBitDepthKey: 16,
                                           AVLinearPCMIsFloatKey: false, AVLinearPCMIsBigEndianKey: false]
            recorder = try AVAudioRecorder(url: url, settings: options)
            recorder?.prepareToRecord(); guard recorder?.record() == true else { throw TTSError.invalidVoice("Không mở được micro") }
            fileURL = url; fileName = "Bản ghi âm mới"
            isRecording = true; status = "Đang ghi âm… bấm lần nữa để dừng"
        } catch { errorText = "Lỗi ghi âm: \(error.localizedDescription)" }
    }

    func createVoice(onCreated: @escaping (String) -> Void) {
        guard !busy, !isRecording else { return }
        guard let url = fileURL else { errorText = "Chọn tệp ghi âm hoặc ghi âm giọng mẫu trước."; return }
        guard !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { errorText = "Hãy đặt tên cho giọng mới."; return }
        guard Assets.cloneReady else { errorText = "Bộ cài hiện chưa có chức năng tạo giọng mới."; return }
        busy = true; status = "Đang phân tích giọng…"; errorText = nil
        let label = name, desc = descriptionText
        Task.detached(priority: .userInitiated) { [self] in
            do {
                let encoder = try CloneEngine()
                let profile = try encoder.enroll(referenceURL: url, name: label, description: desc) { message in
                    Task { @MainActor in self.status = message }
                }
                await MainActor.run {
                    self.busy = false; self.status = "Đã lưu giọng \(profile.name)"
                    self.name = ""; self.fileURL = nil; self.fileName = ""; self.reload()
                    onCreated(profile.id)
                }
            } catch {
                await MainActor.run { self.busy = false; self.errorText = error.localizedDescription; self.status = "" }
            }
        }
    }

    func remove(_ id: String) {
        do { try CloneVoiceStore.delete(id); reload() }
        catch { errorText = "Không xóa được giọng này: \(error.localizedDescription)" }
    }
}

enum SubtitleParser {
    static func toPlainText(_ srt: String) -> String {
        let blocks = srt.replacingOccurrences(of: "\r\n", with: "\n").components(separatedBy: "\n\n")
        var subtitles: [String] = []
        for block in blocks {
            let lines = block.components(separatedBy: "\n").filter { !$0.isEmpty }
            guard let timer = lines.firstIndex(where: { $0.contains("-->") }) else { continue }
            let content = lines.dropFirst(timer + 1).joined(separator: " ")
            if !content.isEmpty { subtitles.append(content) }
        }
        return subtitles.isEmpty ? srt : subtitles.joined(separator: "\n")
    }
}
