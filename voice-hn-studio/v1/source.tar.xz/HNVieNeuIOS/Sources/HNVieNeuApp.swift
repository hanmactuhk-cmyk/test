import SwiftUI
import UniformTypeIdentifiers

@main
struct VoiceHnStudioApp: App {
    var body: some Scene {
        WindowGroup { VoiceStudioRoot().preferredColorScheme(.dark) }
    }
}

private enum Theme {
    static let night = Color(red: 0.015, green: 0.045, blue: 0.12)
    static let navy = Color(red: 0.035, green: 0.10, blue: 0.25)
    static let cyan = Color(red: 0.0, green: 0.90, blue: 0.96)
    static let royal = Color(red: 0.10, green: 0.34, blue: 1.0)
    static let muted = Color(red: 0.64, green: 0.75, blue: 0.88)
    static let glow = LinearGradient(colors: [royal, Color(red: 0.02, green: 0.60, blue: 0.96), cyan], startPoint: .leading, endPoint: .trailing)
}

private struct Glass: ViewModifier {
    var radius: CGFloat = 22
    func body(content: Content) -> some View {
        content
            .background(LinearGradient(colors: [Theme.navy.opacity(0.94), Theme.night.opacity(0.95)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: radius))
            .overlay(RoundedRectangle(cornerRadius: radius).stroke(LinearGradient(colors: [Theme.cyan.opacity(0.62), Theme.royal.opacity(0.18), Theme.cyan.opacity(0.35)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1))
            .shadow(color: Theme.royal.opacity(0.15), radius: 13, y: 5)
    }
}

private extension View {
    func glass(_ radius: CGFloat = 22) -> some View { modifier(Glass(radius: radius)) }
}

private struct PrimaryPill: View {
    let title: String
    let icon: String
    var loading: Bool = false
    var body: some View {
        HStack(spacing: 12) {
            if loading { ProgressView().tint(.white) }
            else { Image(systemName: icon).font(.title3) }
            Text(title).font(.headline.weight(.bold))
            Spacer(minLength: 0)
            Image(systemName: "arrow.right").font(.headline.weight(.bold))
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 22)
        .frame(height: 62)
        .background(Theme.glow, in: Capsule())
        .overlay(Capsule().stroke(.white.opacity(0.65), lineWidth: 1))
        .shadow(color: Theme.cyan.opacity(0.4), radius: 15, y: 5)
    }
}

private struct Headline: View {
    var body: some View {
        HStack(spacing: 12) {
            Image("BrandMark").resizable().frame(width: 57, height: 57).clipShape(RoundedRectangle(cornerRadius: 15))
                .overlay(RoundedRectangle(cornerRadius: 15).stroke(Theme.cyan.opacity(0.55), lineWidth: 1))
            VStack(alignment: .leading, spacing: 3) {
                (Text("Voice Hn ").foregroundColor(.white) + Text("Studio").foregroundColor(Theme.cyan))
                    .font(.system(size: 23, weight: .bold, design: .rounded))
                Text("Biến ý tưởng thành giọng nói sống động")
                    .font(.caption).foregroundStyle(Theme.muted).lineLimit(2)
            }
            Spacer(minLength: 0)
        }
    }
}

struct VoiceStudioRoot: View {
    @StateObject private var studio = SpeechStudio()
    @StateObject private var clone = CloneStudio()
    @State private var tab: Int = 0
    @State private var showingImportText = false
    @State private var showingImportAudio = false

    var body: some View {
        TabView(selection: $tab) {
            ZStack { canvas; home }
                .tabItem { Label("Trang chủ", systemImage: "house.fill") }.tag(0)
            ZStack { canvas; voices }
                .tabItem { Label("Giọng", systemImage: "waveform") }.tag(1)
            ZStack { canvas; cloning }
                .tabItem { Label("Clone", systemImage: "person.wave.2.fill") }.tag(2)
            ZStack { canvas; settings }
                .tabItem { Label("Cài đặt", systemImage: "gearshape.fill") }.tag(3)
        }
        .tint(Theme.cyan)
        .fileImporter(isPresented: $showingImportText, allowedContentTypes: [.plainText, UTType(filenameExtension: "srt") ?? .plainText]) { result in
            switch result { case .success(let url): studio.importText(from: url); case .failure(let error): studio.errorText = error.localizedDescription }
        }
        .fileImporter(isPresented: $showingImportAudio, allowedContentTypes: [.audio]) { result in
            switch result { case .success(let url): clone.importAudio(url); case .failure(let error): clone.errorText = error.localizedDescription }
        }
        .onChange(of: tab) { _ in studio.refresh(); clone.reload() }
    }

    private var canvas: some View {
        GeometryReader { geometry in
            ZStack {
                Theme.night.ignoresSafeArea()
                Circle().fill(Theme.royal.opacity(0.22)).frame(width: 280, height: 280).blur(radius: 100)
                    .position(x: geometry.size.width * 0.9, y: 125)
                Circle().fill(Theme.cyan.opacity(0.09)).frame(width: 300, height: 300).blur(radius: 100)
                    .position(x: 20, y: geometry.size.height * 0.8)
            }
        }.ignoresSafeArea()
    }

    private var home: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                Headline().padding(.top, 12)
                VStack(alignment: .leading, spacing: 10) {
                    Label("Nhập văn bản", systemImage: "square.and.pencil").font(.headline)
                    ZStack(alignment: .topLeading) {
                        if studio.text.isEmpty {
                            Text("Nhập nội dung bạn muốn chuyển thành giọng nói…")
                                .foregroundStyle(Theme.muted.opacity(0.7)).padding(.top, 12).padding(.leading, 5)
                        }
                        TextEditor(text: $studio.text).scrollContentBackground(.hidden)
                            .foregroundStyle(.white).frame(minHeight: 128)
                    }
                    HStack {
                        Text("\(studio.text.count) ký tự").font(.caption).foregroundStyle(Theme.muted)
                        Spacer()
                        Button { showingImportText = true } label: { Label("Nhập TXT/SRT", systemImage: "doc.text") }
                            .font(.caption.weight(.semibold)).tint(Theme.cyan)
                    }
                }.padding(18).glass()

                VStack(alignment: .leading, spacing: 14) {
                    HStack { Label("Giọng đang chọn", systemImage: "waveform").font(.subheadline.weight(.semibold)); Spacer() }
                    Menu {
                        ForEach(studio.voiceChoices) { voice in
                            Button(voice.title) { studio.selectedVoice = voice.id }
                        }
                    } label: {
                        HStack {
                            Image(systemName: "person.crop.circle.fill").foregroundStyle(Theme.cyan)
                            Text(studio.selectedLabel).fontWeight(.semibold).foregroundStyle(.white)
                            Spacer()
                            Image(systemName: "chevron.down").foregroundStyle(Theme.muted)
                        }.padding(12).background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 13))
                    }
                    HStack {
                        Text("Tốc độ đọc").font(.caption).foregroundStyle(Theme.muted)
                        Spacer()
                        Text(String(format: "%.2fx", studio.speed)).font(.caption.monospacedDigit()).foregroundStyle(Theme.cyan)
                    }
                    Slider(value: $studio.speed, in: 0.70...1.35, step: 0.05).tint(Theme.cyan)
                    Picker("Chất lượng", selection: $studio.steps) {
                        Text("Nhanh").tag(8)
                        Text("Mượt mà").tag(16)
                    }.pickerStyle(.segmented)
                }.padding(16).glass()

                Button { studio.synthesize() } label: { PrimaryPill(title: studio.busy ? "Đang tạo giọng…" : "Tạo giọng nói", icon: "waveform", loading: studio.busy) }
                    .disabled(studio.busy || studio.selectedVoice.isEmpty)
                if !studio.progress.isEmpty { Text(studio.progress).font(.caption).foregroundStyle(Theme.muted) }
                if let e = studio.errorText { statusError(e) }
                if let url = studio.resultURL {
                    HStack {
                        Button { studio.playOrPause() } label: {
                            Label(studio.playing ? "Tạm dừng" : "Nghe thử", systemImage: studio.playing ? "pause.fill" : "play.fill")
                        }
                        Spacer()
                        ShareLink(item: url) { Label("Lưu WAV", systemImage: "square.and.arrow.up") }
                    }.font(.subheadline.weight(.semibold)).tint(Theme.cyan).padding(16).glass()
                }
                HStack {
                    Label("Thư viện giọng", systemImage: "waveform").font(.headline)
                    Spacer()
                    Button("Xem tất cả") { tab = 1 }.font(.caption).foregroundStyle(Theme.cyan)
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 12) {
                        ForEach(Array(studio.voiceChoices.prefix(8)).indices, id: \.self) { i in
                            let item = studio.voiceChoices[i]
                            Button { studio.selectedVoice = item.id } label: { voiceCard(item) }
                        }
                    }
                }
                HStack(spacing: 12) {
                    Button { tab = 2 } label: { quickAction("Clone giọng", subtitle: "Tạo giọng riêng của bạn", symbol: "mic.fill", color: Theme.royal) }
                    Button { tab = 3 } label: { quickAction("Lịch sử", subtitle: "Nghe lại file đã tạo", symbol: "clock.arrow.circlepath", color: Theme.cyan) }
                }
                HStack(spacing: 12) {
                    Image("BrandMark").resizable().frame(width: 72, height: 72).clipShape(RoundedRectangle(cornerRadius: 20))
                    VStack(alignment: .leading, spacing: 5) {
                        Text("PHÒNG THU TRONG TÚI BẠN").font(.caption2.weight(.bold)).foregroundStyle(Theme.cyan)
                        Text("Tự nhiên · Chân thực\nĐa phong cách").font(.headline).foregroundStyle(.white)
                    }
                    Spacer()
                }.padding(16).glass()
            }.padding(.horizontal, 16).padding(.bottom, 25)
        }
    }

    private func voiceCard(_ item: VoiceChoice) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack {
                RoundedRectangle(cornerRadius: 16).fill(LinearGradient(colors: [item.tint.opacity(0.5), Theme.navy], startPoint: .top, endPoint: .bottom))
                Image(systemName: item.symbol).font(.system(size: 42, weight: .ultraLight)).foregroundStyle(.white.opacity(0.86))
                VStack { Spacer(); HStack { Image(systemName: "play.fill").font(.caption).padding(8).background(.white.opacity(0.18), in: Circle()); Spacer() } }
                    .padding(8)
            }.frame(height: 105)
            Text(item.title).lineLimit(1).font(.subheadline.weight(.semibold)).foregroundStyle(.white)
            Text(item.detail).lineLimit(1).font(.caption2).foregroundStyle(Theme.muted)
        }.frame(width: 132, alignment: .leading).padding(10)
            .background(Theme.navy.opacity(0.8), in: RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(item.id == studio.selectedVoice ? Theme.cyan : item.tint.opacity(0.55), lineWidth: item.id == studio.selectedVoice ? 1.8 : 0.8))
    }

    private func quickAction(_ title: String, subtitle: String, symbol: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: symbol).font(.title).foregroundStyle(color)
            Text(title).font(.subheadline.bold()).foregroundStyle(.white)
            Text(subtitle).font(.caption2).foregroundStyle(Theme.muted).lineLimit(2)
        }.frame(maxWidth: .infinity, minHeight: 125, alignment: .leading).padding(14).glass()
    }

    private var voices: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Headline().padding(.top, 12)
                sectionTitle("Thư viện giọng", subtitle: "Chọn phong cách đọc phù hợp với nội dung")
                ForEach(studio.voiceChoices) { voice in
                    Button {
                        studio.selectedVoice = voice.id
                        tab = 0
                    } label: {
                        HStack(spacing: 14) {
                            Image(systemName: voice.symbol).font(.title2).foregroundStyle(voice.tint)
                                .frame(width: 52, height: 52).background(voice.tint.opacity(0.17), in: RoundedRectangle(cornerRadius: 15))
                            VStack(alignment: .leading, spacing: 5) {
                                Text(voice.title).font(.headline).foregroundStyle(.white)
                                Text(voice.detail).font(.caption).foregroundStyle(Theme.muted).lineLimit(2)
                            }
                            Spacer()
                            Image(systemName: studio.selectedVoice == voice.id ? "checkmark.circle.fill" : "chevron.right")
                                .foregroundStyle(Theme.cyan)
                        }.padding(14).glass()
                    }
                }
                Button { tab = 2 } label: { PrimaryPill(title: "Tạo giọng của riêng bạn", icon: "mic.fill") }
            }.padding(.horizontal, 16).padding(.bottom, 24)
        }
    }

    private var cloning: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 17) {
                Headline().padding(.top, 12)
                VStack(alignment: .leading, spacing: 6) {
                    (Text("Clone ").foregroundColor(.white) + Text("giọng").foregroundColor(Theme.cyan))
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                    Text("Tạo một giọng đọc mới từ bản ghi có quyền sử dụng.").font(.subheadline).foregroundStyle(Theme.muted)
                }.padding(.vertical, 4)

                VStack(alignment: .leading, spacing: 14) {
                    numbered(1, "Chọn tệp giọng mẫu", subtitle: "Giọng nói rõ ràng, ít tạp âm, tốt nhất 5–15 giây")
                    HStack(spacing: 10) {
                        Button { showingImportAudio = true } label: {
                            VStack(spacing: 10) {
                                Image(systemName: "icloud.and.arrow.up").font(.system(size: 31)).foregroundStyle(Theme.cyan)
                                Text(clone.fileName.isEmpty ? "Tải tệp MP3 / WAV / M4A" : clone.fileName)
                                    .font(.caption.weight(.medium)).multilineTextAlignment(.center).lineLimit(3).foregroundStyle(.white)
                            }.frame(maxWidth: .infinity, minHeight: 116)
                                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Theme.cyan.opacity(0.65), style: StrokeStyle(lineWidth: 1, dash: [5, 4])))
                        }
                        Button { clone.toggleRecording() } label: {
                            VStack(spacing: 10) {
                                Image(systemName: clone.isRecording ? "stop.circle.fill" : "mic.fill")
                                    .font(.system(size: 31)).foregroundStyle(clone.isRecording ? .red : Theme.cyan)
                                Text(clone.isRecording ? "Dừng ghi âm" : "Ghi âm").font(.caption.bold()).foregroundStyle(.white)
                            }.frame(width: 110, height: 116)
                                .background(Theme.royal.opacity(0.2), in: RoundedRectangle(cornerRadius: 16))
                                .overlay(RoundedRectangle(cornerRadius: 16).stroke(Theme.cyan.opacity(0.4)))
                        }
                    }
                }.padding(16).glass()

                VStack(alignment: .leading, spacing: 12) {
                    numbered(2, "Đặt tên giọng", subtitle: "Dễ tìm lại trong thư viện giọng")
                    TextField("Ví dụ: Giọng của tôi", text: $clone.name)
                        .padding(14).foregroundStyle(.white)
                        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 13))
                        .overlay(RoundedRectangle(cornerRadius: 13).stroke(Theme.muted.opacity(0.35)))
                }.padding(16).glass()

                VStack(alignment: .leading, spacing: 12) {
                    numbered(3, "Mô tả giọng", subtitle: "Ghi chú để quản lý, không làm thay đổi âm sắc")
                    TextField("Ví dụ: Trầm · Rõ lời · Bắc", text: $clone.descriptionText)
                        .padding(14).foregroundStyle(.white)
                        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 13))
                    HStack(spacing: 6) { Text("Ấm áp"); Text("·"); Text("Trầm"); Text("·"); Text("Rõ lời") }
                        .font(.caption).foregroundStyle(Theme.cyan)
                }.padding(16).glass()

                Button {
                    clone.createVoice { voiceID in studio.refresh(); studio.selectedVoice = voiceID }
                } label: { PrimaryPill(title: clone.busy ? "Đang tạo giọng…" : "Tạo giọng clone", icon: "sparkles", loading: clone.busy) }
                    .disabled(clone.busy || clone.isRecording)
                if !clone.status.isEmpty { Label(clone.status, systemImage: "waveform").font(.caption).foregroundStyle(Theme.muted) }
                if let e = clone.errorText { statusError(e) }

                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        Label("Giọng đã tạo", systemImage: "waveform").font(.headline)
                        Spacer()
                        Text("\(clone.saved.count) giọng").font(.caption).foregroundStyle(Theme.muted)
                    }
                    if clone.saved.isEmpty {
                        Text("Các giọng bạn tạo từ bản ghi của mình sẽ được lưu tại đây.")
                            .font(.subheadline).foregroundStyle(Theme.muted).padding(.vertical, 8)
                    }
                    ForEach(clone.saved) { voice in
                        HStack(spacing: 12) {
                            Image(systemName: "waveform.circle.fill").font(.title).foregroundStyle(Theme.cyan)
                            VStack(alignment: .leading, spacing: 5) {
                                Text(voice.name).font(.subheadline.bold()).foregroundStyle(.white)
                                Text(voice.description).font(.caption).foregroundStyle(Theme.muted).lineLimit(1)
                            }
                            Spacer()
                            Button { studio.refresh(); studio.selectedVoice = voice.id; tab = 0 } label: {
                                Image(systemName: "play.fill").foregroundStyle(Theme.cyan)
                            }
                            Button(role: .destructive) { clone.remove(voice.id); studio.refresh() } label: {
                                Image(systemName: "trash").foregroundStyle(.red.opacity(0.7))
                            }
                        }.padding(12).background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 14))
                    }
                }.padding(16).glass()
                Text("Chỉ nhân bản giọng của bạn hoặc người đã đồng ý. Tệp và giọng mới được lưu trên iPhone.")
                    .font(.caption2).foregroundStyle(Theme.muted).padding(.horizontal, 4)
            }.padding(.horizontal, 16).padding(.bottom, 30)
        }
    }

    private var settings: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Headline().padding(.top, 12)
                sectionTitle("Cài đặt", subtitle: "Phòng thu riêng tư trên iPhone")
                HStack { Image(systemName: "wifi.slash").foregroundStyle(Theme.cyan); VStack(alignment: .leading) {
                    Text("Xử lý trên thiết bị").font(.headline)
                    Text("Không cần máy chủ để tạo giọng").font(.caption).foregroundStyle(Theme.muted)
                }; Spacer(); Image(systemName: "checkmark.shield.fill").foregroundStyle(.green) }.padding(16).glass()
                VStack(alignment: .leading, spacing: 16) {
                    Label("Lịch sử WAV", systemImage: "clock").font(.headline)
                    if studio.history.isEmpty { Text("Chưa có file WAV nào").font(.caption).foregroundStyle(Theme.muted) }
                    ForEach(studio.history, id: \.path) { url in
                        HStack {
                            Image(systemName: "waveform").foregroundStyle(Theme.cyan)
                            Text(url.lastPathComponent).font(.caption).lineLimit(1)
                            Spacer()
                            Button { studio.playOrPause(url) } label: { Image(systemName: "play.circle.fill") }
                            ShareLink(item: url) { Image(systemName: "square.and.arrow.up") }
                        }.tint(Theme.cyan)
                    }
                }.padding(16).glass()
                Text("Voice Hn Studio · Phiên bản 1.0").font(.caption).foregroundStyle(Theme.muted)
            }.padding(.horizontal, 16).padding(.bottom, 24)
        }
    }

    private func numbered(_ number: Int, _ title: String, subtitle: String) -> some View {
        HStack(alignment: .top, spacing: 12) {
            Text("\(number)").font(.headline.bold()).foregroundStyle(Theme.cyan)
                .frame(width: 36, height: 36).background(Theme.cyan.opacity(0.12), in: Circle())
                .overlay(Circle().stroke(Theme.cyan.opacity(0.75)))
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.headline).foregroundStyle(.white)
                Text(subtitle).font(.caption).foregroundStyle(Theme.muted)
            }
        }
    }

    private func sectionTitle(_ title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.system(size: 30, weight: .bold, design: .rounded))
            Text(subtitle).font(.subheadline).foregroundStyle(Theme.muted)
        }
    }

    private func statusError(_ text: String) -> some View {
        Label(text, systemImage: "exclamationmark.circle")
            .font(.caption).foregroundStyle(.orange).padding(12)
            .frame(maxWidth: .infinity, alignment: .leading).glass(12)
    }
}
