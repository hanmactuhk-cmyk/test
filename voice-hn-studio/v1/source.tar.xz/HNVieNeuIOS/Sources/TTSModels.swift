import Foundation

enum TTSError: LocalizedError {
    case missingAssets(String), invalidModel(String), invalidVoice(String), emptyText
    case noGeneratedAudio, inferenceFailure(String)

    var errorDescription: String? {
        switch self {
        case .missingAssets(let p): return "Thiếu dữ liệu offline: \(p). Chạy scripts/prepare_assets.py trước khi build."
        case .invalidModel(let m): return "Mô hình không hợp lệ: \(m)"
        case .invalidVoice(let v): return "Giọng đọc không hợp lệ: \(v)"
        case .emptyText: return "Vui lòng nhập văn bản tiếng Việt."
        case .noGeneratedAudio: return "Không tạo được dữ liệu âm thanh."
        case .inferenceFailure(let s): return "Lỗi suy luận VieNeu: \(s)"
        }
    }
}

struct NanoConfig: Decodable {
    let vocab: [String: Int]
    let bos_id: Int
    let eos_id: Int
    let pad_id: Int
    let flow_fps: Double?
    let emotion_tags: [String: String]?
}

struct NanoConstants: Decodable {
    let null_spk: [Float]
    let null_style: [Float]
    let latent_mean: [Float]?
    let latent_std: [Float]?
    let latent_scale: Float?
}

struct NanoVoice: Codable {
    let description: String?
    let gender: String?
    let speaker_emb: [Float]
    let style: [[Float]]
    var flatStyle: [Float] { style.flatMap { $0 } }
}

struct NanoVoices: Decodable {
    let default_voice: String
    let presets: [String: NanoVoice]
}

struct TTSSettings: Sendable {
    var voice: String
    var steps: Int = 8
    var cfg: Float = 3
    var sway: Float = -1
    var speed: Float = 1
    var seed: UInt64 = 2026
}

struct Assets {
    static let modelNames = ["text_encoder.onnx", "duration_predictor.onnx", "vector_estimator.onnx", "codec_decoder.onnx"]
    static let cloneNames = ["speaker_encoder.onnx", "codec_encoder.onnx", "reference_encoder.onnx"]
    static var modelDirectory: URL? { Bundle.main.url(forResource: "Models", withExtension: nil) }
    static var dataDirectory: URL? { Bundle.main.url(forResource: "Data", withExtension: nil) }
    static func modelPath(_ name: String) throws -> String {
        guard let url = modelDirectory?.appendingPathComponent(name),
              FileManager.default.fileExists(atPath: url.path) else { throw TTSError.missingAssets("Models/\(name)") }
        return url.path
    }
    static func dataURL(_ name: String) throws -> URL {
        guard let url = dataDirectory?.appendingPathComponent(name),
              FileManager.default.fileExists(atPath: url.path) else { throw TTSError.missingAssets("Data/\(name)") }
        return url
    }
    static var cloneReady: Bool {
        cloneNames.allSatisfy { (try? modelPath($0)) != nil } && ready
    }
    static var ready: Bool {
        modelNames.allSatisfy { name in (try? modelPath(name)) != nil } &&
        (try? dataURL("config.json")) != nil &&
        (try? dataURL("constants.json")) != nil &&
        (try? dataURL("voices_v3_nano.json")) != nil &&
        (try? dataURL("sea_g2p.bin")) != nil
    }
}
