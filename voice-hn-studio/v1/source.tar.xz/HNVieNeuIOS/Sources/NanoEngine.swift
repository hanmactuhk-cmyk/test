import Foundation

/// Direct Swift implementation of upstream VieNeu-TTS v3 Nano ONNX inference:
/// text encoder -> duration -> Euler flow-matching with CFG -> codec decoder.
/// Mirrors v3nano.py, using actual ONNX models, not Apple system TTS.
final class NanoEngine {
    private let cfg: NanoConfig
    private let consts: NanoConstants
    private let voices: NanoVoices
    private let graphs: OrtGraphs
    private let g2p: SeaG2P
    private let nullContext: OrtTensor
    private let nullMask: OrtTensor

    init() throws {
        let decoder = JSONDecoder()
        cfg = try decoder.decode(NanoConfig.self, from: Data(contentsOf: Assets.dataURL("config.json")))
        consts = try decoder.decode(NanoConstants.self, from: Data(contentsOf: Assets.dataURL("constants.json")))
        voices = try decoder.decode(NanoVoices.self, from: Data(contentsOf: Assets.dataURL("voices_v3_nano.json")))
        guard consts.null_spk.count == 192, consts.null_style.count == 50 * 256 else {
            throw TTSError.invalidModel("Các tensor null_spk/null_style có kích thước khác tài liệu")
        }
        g2p = try SeaG2P()
        graphs = try OrtGraphs()
        nullContext = try graphs.run("text_encoder", [
            "ids": .i([Int64(cfg.bos_id), Int64(cfg.eos_id)], [1, 2]),
            "style": .f(consts.null_style, [1, 50, 256])
        ])
        nullMask = .b([1, 1], [1, 2])
    }

    var presetNames: [String] { voices.presets.keys.sorted() }
    var defaultVoice: String { voices.default_voice }

    func synthesize(_ text: String, settings: TTSSettings, progress: (Int, Int) -> Void = { _,_ in }) throws -> [Float] {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { throw TTSError.emptyText }
        guard let voice = voices.presets[settings.voice] ?? CloneVoiceStore.load(id: settings.voice)?.nanoVoice else { throw TTSError.invalidVoice(settings.voice) }
        guard voice.speaker_emb.count == 192 && voice.flatStyle.count == 50 * 256 else {
            throw TTSError.invalidVoice("Sai vector x-vector/style")
        }
        let chunks = TextChunker.split(trimmed, limit: 140)
        var result: [Float] = []
        for (index, chunk) in chunks.enumerated() {
            let phonemes = try g2p.phones(chunk)
            let audio = try oneChunk(phonemes: phonemes, voice: voice, settings: settings, chunk: index)
            if index > 0 { result += [Float](repeating: 0, count: 2_400) } // 100 ms at 24 kHz
            result.append(contentsOf: audio)
            progress(index + 1, chunks.count)
        }
        guard !result.isEmpty else { throw TTSError.noGeneratedAudio }
        return result
    }

    private func oneChunk(phonemes: String, voice: NanoVoice, settings: TTSSettings, chunk: Int) throws -> [Float] {
        var rendered = phonemes
        for (tag, character) in cfg.emotion_tags ?? [:] { rendered = rendered.replacingOccurrences(of: tag, with: character) }
        var ids: [Int64] = [Int64(cfg.bos_id)]
        for scalar in rendered.unicodeScalars {
            if let val = cfg.vocab[String(scalar)] { ids.append(Int64(val)) }
        }
        ids.append(Int64(cfg.eos_id))
        let mask = OrtTensor.b(ids.map { $0 == Int64(cfg.pad_id) ? UInt8(0) : UInt8(1) }, [1, ids.count])
        let style = OrtTensor.f(voice.flatStyle, [1, 50, 256])
        let spk = OrtTensor.f(voice.speaker_emb, [1, 192])
        let ctx = try graphs.run("text_encoder", ["ids": .i(ids, [1, ids.count]), "style": style])
        let duration = try graphs.run("duration_predictor", ["ctx": ctx, "ctx_mask": mask, "spk": spk])
        guard let logSeconds = duration.floats.first, logSeconds.isFinite else {
            throw TTSError.inferenceFailure("duration_predictor trả về số không hợp lệ")
        }
        let seconds = min(exp(Double(logSeconds)) / Double(max(settings.speed, 0.1)), 15)
        guard seconds.isFinite && seconds > 0 else { throw TTSError.inferenceFailure("Thời lượng dự đoán sai") }
        let frames = max(2, Int((seconds * (cfg.flow_fps ?? 15.625)).rounded()))
        var normal = BoxMuller(seed: settings.seed &+ UInt64(chunk))
        var latents = (0..<(144 * frames)).map { _ in normal.next() }
        let n = max(1, min(32, settings.steps))
        func t(_ i: Int) -> Double {
            let u = Double(i) / Double(n)
            return u + Double(settings.sway) * (cos(.pi / 2 * u) - 1 + u)
        }
        for i in 0..<n {
            let inputs: [String: OrtTensor] = [
                "x": .f(latents, [1, 144, frames]), "t": .f([Float(t(i))], [1]),
                "ctx": ctx, "ctx_mask": mask, "spk": spk, "style": style
            ]
            var v = try graphs.run("vector_estimator", inputs).floats
            if settings.cfg > 0 {
                let uncond = try graphs.run("vector_estimator", [
                    "x": .f(latents, [1, 144, frames]), "t": .f([Float(t(i))], [1]),
                    "ctx": nullContext, "ctx_mask": nullMask,
                    "spk": .f(consts.null_spk, [1, 192]),
                    "style": .f(consts.null_style, [1, 50, 256])
                ]).floats
                guard v.count == uncond.count else { throw TTSError.inferenceFailure("CFG sai tensor") }
                for j in v.indices { v[j] = uncond[j] + settings.cfg * (v[j] - uncond[j]) }
            }
            guard v.count == latents.count else { throw TTSError.inferenceFailure("Flow shape sai") }
            let dt = Float(t(i + 1) - t(i))
            for j in latents.indices { latents[j] += dt * v[j] }
        }
        let wav = try graphs.run("codec_decoder", ["x": .f(latents, [1, 144, frames])])
        guard !wav.floats.isEmpty else { throw TTSError.noGeneratedAudio }
        return AudioUtils.trimAndFade(wav.floats)
    }
}

private struct BoxMuller {
    private var state: UInt64
    private var spare: Double?
    init(seed: UInt64) { state = seed }
    private mutating func uniform() -> Double {
        state &+= 0x9E3779B97F4A7C15
        var z = state
        z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
        z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
        z = z ^ (z >> 31)
        return max(Double(z >> 11) / 9007199254740992, 1e-12)
    }
    mutating func next() -> Float {
        if let x = spare { spare = nil; return Float(x) }
        let r = sqrt(-2.0 * log(uniform()))
        let a = 2.0 * Double.pi * uniform()
        spare = r * sin(a)
        return Float(r * cos(a))
    }
}

enum TextChunker {
    static func split(_ text: String, limit: Int) -> [String] {
        let lines = text.replacingOccurrences(of: "\r", with: "").components(separatedBy: "\n")
        var chunks: [String] = []
        for line in lines {
            let cleaned = line.trimmingCharacters(in: .whitespacesAndNewlines)
            if cleaned.isEmpty { continue }
            let words = cleaned.split(whereSeparator: { $0.isWhitespace })
            var current = ""
            for word in words {
                let w = String(word)
                if current.isEmpty { current = w; continue }
                if current.count + w.count + 1 > limit {
                    chunks.append(current); current = w
                } else { current += " " + w }
            }
            if !current.isEmpty { chunks.append(current) }
        }
        return chunks
    }
}
