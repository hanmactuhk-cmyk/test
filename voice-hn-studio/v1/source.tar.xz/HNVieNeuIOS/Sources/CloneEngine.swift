import AVFoundation
import Foundation

/// Extracts a cloned voice entirely on the phone; no requests leave the device.
final class CloneEngine {
    private let graphs: OrtGraphs
    private let constants: NanoConstants
    private let config: NanoConfig

    init() throws {
        guard Assets.cloneReady else { throw TTSError.missingAssets("Chưa đóng gói đủ dữ liệu clone giọng") }
        constants = try JSONDecoder().decode(NanoConstants.self, from: Data(contentsOf: Assets.dataURL("constants.json")))
        config = try JSONDecoder().decode(NanoConfig.self, from: Data(contentsOf: Assets.dataURL("config.json")))
        graphs = try OrtGraphs(models: Assets.cloneNames)
    }

    func enroll(referenceURL: URL, name: String, description: String, progress: @escaping (String) -> Void = { _ in }) throws -> SavedVoice {
        let scoped = referenceURL.startAccessingSecurityScopedResource()
        defer { if scoped { referenceURL.stopAccessingSecurityScopedResource() } }
        progress("Đang đọc tệp ghi âm…")
        let sample = try SampleAudio.load(url: referenceURL, maxSeconds: 30)
        guard sample.duration >= 1.0 else { throw TTSError.invalidVoice("Đoạn ghi âm quá ngắn. Nên dùng 5–15 giây giọng nói rõ ràng.") }
        let s16 = SampleAudio.resample(sample.samples, from: sample.sampleRate, to: 16_000)
        let s24 = SampleAudio.resample(sample.samples, from: sample.sampleRate, to: 24_000)

        progress("Đang nhận diện chất giọng…")
        let fbank = try SpeakerFbank.extract(s16)
        let frames = fbank.count / 80
        let speaker = try graphs.run("speaker_encoder", ["input": .f(fbank, [1, frames, 80])]).floats
        guard speaker.count == 192 else { throw TTSError.invalidVoice("Không lấy được đặc điểm giọng nói.") }

        progress("Đang ghi nhớ phong cách giọng…")
        let maxSamples = min(s24.count, 24_000 * 5)
        let wave = Array(s24.prefix(maxSamples))
        let codecInput = try graphs.firstInputName("codec_encoder")
        let codec = try graphs.run("codec_encoder", [codecInput: .f(wave, [1, 1, wave.count])])
        guard codec.shape.count == 3, codec.shape[0] == 1, codec.shape[1] == 24 else {
            throw TTSError.invalidVoice("Dữ liệu âm thanh đầu vào không phù hợp.")
        }
        guard let mu = constants.latent_mean, let std = constants.latent_std, mu.count == 24, std.count == 24 else {
            throw TTSError.invalidVoice("Thiếu dữ liệu phong cách giọng.")
        }
        let inputFrames = codec.shape[2]
        let group = 6
        let groupedFrames = min((inputFrames + group - 1) / group, 140)
        guard groupedFrames >= 1 else { throw TTSError.invalidVoice("Bản ghi không có đủ tiếng nói.") }
        let scale = constants.latent_scale ?? 1
        var grouped = [Float](repeating: 0, count: 24 * group * groupedFrames)
        for channel in 0..<24 {
            let divisor = max(abs(std[channel]), 1e-6)
            for frame in 0..<groupedFrames {
                for part in 0..<group {
                    let srcT = frame * group + part
                    guard srcT < inputFrames else { continue }
                    let src = codec.floats[channel * inputFrames + srcT]
                    grouped[(channel * group + part) * groupedFrames + frame] = (src - mu[channel]) / divisor * scale
                }
            }
        }
        let mask = [UInt8](repeating: 1, count: groupedFrames)
        let styleTensor = try graphs.run("reference_encoder", [
            "ref": .f(grouped, [1, 24 * group, groupedFrames]),
            "ref_mask": .b(mask, [1, groupedFrames])
        ])
        guard styleTensor.floats.count == 50 * 256 else { throw TTSError.invalidVoice("Không trích xuất được phong cách giọng.") }
        let rows = (0..<50).map { row in Array(styleTensor.floats[(row*256)..<((row+1)*256)]) }
        progress("Đang lưu giọng mới…")
        return try CloneVoiceStore.save(name: name, description: description, speaker: speaker, style: rows)
    }
}

struct SampleAudio {
    let samples: [Float]
    let sampleRate: Double
    var duration: Double { Double(samples.count) / sampleRate }

    static func load(url: URL, maxSeconds: Int) throws -> SampleAudio {
        let file = try AVAudioFile(forReading: url)
        let format = file.processingFormat
        let sampleRate = format.sampleRate
        let maxFrames = max(1, min(file.length, AVAudioFramePosition(sampleRate * Double(maxSeconds))))
        guard let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(maxFrames)) else {
            throw TTSError.invalidVoice("Không thể mở tệp ghi âm.")
        }
        try file.read(into: buffer, frameCount: AVAudioFrameCount(maxFrames))
        guard buffer.frameLength > 0, let channels = buffer.floatChannelData else {
            throw TTSError.invalidVoice("Tệp âm thanh không có dữ liệu PCM.")
        }
        let count = Int(buffer.frameLength)
        let n = Int(format.channelCount)
        var mono = [Float](repeating: 0, count: count)
        for channel in 0..<n {
            let ptr = channels[channel]
            for i in 0..<count { mono[i] += ptr[i] / Float(n) }
        }
        // Peak-normalize quiet reference files without amplifying silence excessively.
        let maxAbs = mono.reduce(Float(0)) { max($0, abs($1)) }
        guard maxAbs > 0.001 else { throw TTSError.invalidVoice("Không phát hiện tiếng nói trong file.") }
        let gain = min(Float(1.0) / maxAbs, Float(5))
        if gain > 1 { for i in mono.indices { mono[i] *= gain } }
        return SampleAudio(samples: mono, sampleRate: sampleRate)
    }

    static func resample(_ audio: [Float], from sourceHz: Double, to targetHz: Double) -> [Float] {
        guard !audio.isEmpty, sourceHz > 0, targetHz > 0 else { return [] }
        if abs(sourceHz - targetHz) < 0.001 { return audio }
        let length = max(1, Int((Double(audio.count) * targetHz / sourceHz).rounded()))
        let ratio = sourceHz / targetHz
        return (0..<length).map { i in
            let t = min(Double(audio.count - 1), Double(i) * ratio)
            let a = min(audio.count - 1, Int(t))
            let b = min(audio.count - 1, a + 1)
            return audio[a] * Float(1 - (t - Double(a))) + audio[b] * Float(t - Double(a))
        }
    }
}

/// Kaldi-style 80-filterbank log-mel frontend for the ONNX speaker encoder.
/// Uses a 25-ms Povey window, 10-ms hop, DC removal, pre-emphasis and mean normalization.
/// A direct Swift FFT avoids depending on Python/torch at runtime.
enum SpeakerFbank {
    static func extract(_ waveform: [Float]) throws -> [Float] {
        let sampleRate = 16_000.0
        let frameLength = 400, frameShift = 160, fftSize = 512, bins = 257, melCount = 80
        guard waveform.count >= frameLength else { throw TTSError.invalidVoice("Bản ghi quá ngắn để nhận diện giọng.") }
        let nframes = 1 + (waveform.count - frameLength) / frameShift
        var filters = [[Float]](repeating: [Float](repeating: 0, count: bins), count: melCount)
        func mel(_ hertz: Double) -> Double { 1127 * log(1 + hertz / 700) }
        let lowMel = mel(20), highMel = mel(8000)
        let points = (0..<(melCount+2)).map { lowMel + (highMel-lowMel)*Double($0)/Double(melCount+1) }
        for j in 0..<bins {
            let freq = sampleRate * Double(j) / Double(fftSize)
            let m = mel(freq)
            for k in 0..<melCount {
                if m >= points[k], m <= points[k+1] {
                    filters[k][j] = Float((m-points[k]) / (points[k+1]-points[k]))
                } else if m > points[k+1], m <= points[k+2] {
                    filters[k][j] = Float((points[k+2]-m)/(points[k+2]-points[k+1]))
                }
            }
        }
        let window: [Float] = (0..<frameLength).map { Float(pow(0.5 - 0.5*cos(2*Double.pi*Double($0)/Double(frameLength-1)),0.85)) }
        var features = [Float](repeating: 0, count: nframes * melCount)
        var means = [Float](repeating: 0, count: melCount)
        for frame in 0..<nframes {
            let start = frame * frameShift
            let mean = waveform[start..<(start+frameLength)].reduce(Float(0), +) / Float(frameLength)
            var real = [Float](repeating: 0, count: fftSize)
            var imag = [Float](repeating: 0, count: fftSize)
            var previous: Float = 0
            for i in 0..<frameLength {
                let x = waveform[start+i] - mean
                real[i] = (x - 0.97*previous) * window[i]
                previous = x
            }
            fft(real: &real, imag: &imag)
            var power = [Float](repeating: 0, count: bins)
            for i in 0..<bins { power[i] = real[i]*real[i] + imag[i]*imag[i] }
            for k in 0..<melCount {
                var energy: Float = 0
                for j in 0..<bins { energy += power[j]*filters[k][j] }
                let logEnergy = log(max(energy, 1.1920929e-7))
                features[frame*melCount+k] = logEnergy
                means[k] += logEnergy
            }
        }
        for k in 0..<melCount { means[k] /= Float(nframes) }
        for frame in 0..<nframes {
            for k in 0..<melCount { features[frame*melCount+k] -= means[k] }
        }
        return features
    }

    private static func fft(real: inout [Float], imag: inout [Float]) {
        let n = real.count
        var j = 0
        for i in 1..<n {
            var bit = n >> 1
            while (j & bit) != 0 { j ^= bit; bit >>= 1 }
            j ^= bit
            if i < j { real.swapAt(i, j); imag.swapAt(i, j) }
        }
        var len = 2
        while len <= n {
            let angle = -2 * Float.pi / Float(len)
            let wrBase = cos(angle), wiBase = sin(angle)
            for start in stride(from: 0, to: n, by: len) {
                var wr: Float = 1, wi: Float = 0
                for k in 0..<(len/2) {
                    let i = start+k, j = i + len/2
                    let tr = wr*real[j] - wi*imag[j]
                    let ti = wr*imag[j] + wi*real[j]
                    real[j] = real[i]-tr; imag[j] = imag[i]-ti
                    real[i] += tr; imag[i] += ti
                    let nextR = wr*wrBase - wi*wiBase
                    wi = wr*wiBase + wi*wrBase
                    wr = nextR
                }
            }
            len <<= 1
        }
    }
}
