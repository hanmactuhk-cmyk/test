# Voice Hn Studio — iPhone offline AI voice creation

Ứng dụng SwiftUI iOS, tạo giọng đọc tiếng Việt hoàn toàn trên iPhone bằng các bộ mô hình VieNeu v3 Nano (model được gói sẵn), không sử dụng Internet/API ở thời gian chạy.

Tính năng: chọn 11 giọng có sẵn, nhập văn bản TXT/SRT, tổng hợp WAV 24 kHz, phát/nghe/lưu, nhập WAV/MP3/M4A hoặc tự ghi âm, trích xuất giọng mới qua speaker encoder + codec encoder + reference encoder ONNX, lưu giọng mới trong iPhone và dùng giọng đó để tổng hợp văn bản.

Cần cấp quyền micro khi ghi âm, không bắt buộc khi nhập file. Tạo giọng riêng chỉ từ bản ghi của chính bạn hoặc bản ghi mà chủ giọng đã cho phép sử dụng. Không có bản sao giọng các nhân vật nổi tiếng được đóng gói sẵn. Giọng trong thư viện là các preset thực sự có trong VieNeu Nano.

Tên sản phẩm trên UI: **Voice Hn Studio**; tên các engine bị ẩn khỏi giao diện.

## Build

On macOS with Xcode + xcodegen + CocoaPods + Rust:

```bash
bash scripts/setup_mac.sh
source .venv/bin/activate
pip install 'onnx>=1.18,<1.21'
python scripts/patch_runtime.py
xcodebuild -workspace HNVieNeuIOS.xcworkspace -scheme HNVieNeuIOS -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath DerivedData CODE_SIGNING_ALLOWED=NO build
```

To package an unsigned IPA: `mkdir -p Payload; cp -R DerivedData/Build/Products/Release-iphoneos/HNVieNeuIOS.app Payload/; zip -qr Voice-Hn-Studio-UNSIGNED.ipa Payload`.

This source is an implementation, not proof that the cloned voice has been validated on an actual iPhone. Voice extraction uses a Swift approximation to Kaldi's 80-mel fbank; fidelity and speed may differ from the Python reference. Testing on device is required.
